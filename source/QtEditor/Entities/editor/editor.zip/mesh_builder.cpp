// editor/mesh_builder.cpp
#include "mesh_builder.h"
#include "topology.h"
#include <glm/gtc/matrix_transform.hpp>
#include <algorithm>
#include <cmath>

namespace editor {

static bool nearVec3(const glm::vec3& a, const glm::vec3& b, float eps = kEpsilon * 10.f) noexcept
{
    return glm::length(a - b) <= eps;
}

static void cleanupPolygon(std::vector<glm::vec3>& poly)
{
    if (poly.size() < 3) {
        poly.clear();
        return;
    }

    // Step 1: Remove adjacent duplicates + closing vertex
    std::vector<glm::vec3> deduped;
    deduped.reserve(poly.size());

    for (const auto& p : poly) {
        if (deduped.empty() || !nearVec3(deduped.back(), p))
            deduped.push_back(p);
    }

    if (deduped.size() >= 2 && nearVec3(deduped.front(), deduped.back()))
        deduped.pop_back();

    if (deduped.size() < 3) {
        poly.clear();
        return;
    }

    // Step 2: Remove nearly collinear points (much more robust version)
    std::vector<glm::vec3> cleaned;
    cleaned.reserve(deduped.size());

    for (size_t i = 0; i < deduped.size(); ++i) {
        const glm::vec3& prev = deduped[(i + deduped.size() - 1) % deduped.size()];
        const glm::vec3& curr = deduped[i];
        const glm::vec3& next = deduped[(i + 1) % deduped.size()];

        glm::vec3 a = curr - prev;
        glm::vec3 b = next - curr;

        float lenA2 = glm::dot(a, a);
        float lenB2 = glm::dot(b, b);
        float crossLen = glm::length(glm::cross(a, b));

        float maxEdgeLen = std::sqrt(std::max(lenA2, lenB2));

        // Keep if:
        // - very short edge (important for small details)
        // - or forms a meaningful angle
        if (maxEdgeLen < kEpsilon * 2.0f || crossLen > kEpsilon * 0.25f * maxEdgeLen) {
            cleaned.push_back(curr);
        }
    }

    // Fallback if cleanup was too aggressive
    if (cleaned.size() >= 3)
        poly.swap(cleaned);
    else
        poly.swap(deduped);
}

// ─────────────────────────────────────────────────────────────────────────────
// clipPolygonByPlane  (Sutherland-Hodgman single half-space)
// Inside = back side: distanceTo(P) <= +kEpsilon
// ─────────────────────────────────────────────────────────────────────────────

std::vector<glm::vec3> clipPolygonByPlane(const std::vector<glm::vec3>& poly,
                                          const Plane& plane)
{
    if (poly.size() < 3) return {};

    std::vector<glm::vec3> out;
    out.reserve(poly.size() + 2);

    for (size_t i = 0; i < poly.size(); ++i) {
        const glm::vec3& curr = poly[i];
        const glm::vec3& next = poly[(i + 1) % poly.size()];

        float dCurr = plane.distanceTo(curr);
        float dNext = plane.distanceTo(next);

        bool insideCurr = (dCurr <= kEpsilon);
        bool insideNext = (dNext <= kEpsilon);

        if (insideCurr) {
            if (out.empty() || !nearVec3(out.back(), curr))
                out.push_back(curr);
        }

        if (insideCurr != insideNext) {
            float denom = dCurr - dNext;
            if (std::fabs(denom) > 1e-8f) {
                float t = dCurr / denom;
                glm::vec3 hit = curr + t * (next - curr);

                // Snap to plane to reduce floating point drift
                float dist = plane.distanceTo(hit);
                hit -= dist * plane.normal;

                if (out.empty() || !nearVec3(out.back(), hit))
                    out.push_back(hit);
            }
        }
    }

    cleanupPolygon(out);
    return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// buildInitialPolygon — large quad exactly in `plane`
// ─────────────────────────────────────────────────────────────────────────────

static std::vector<glm::vec3> buildInitialPolygon(const Plane& plane)
{
    const glm::vec3& n = plane.normal;
    glm::vec3 up = (std::fabs(n.z) < 0.9f)
                 ? glm::vec3(0.f, 0.f, 1.f)
                 : glm::vec3(0.f, 1.f, 0.f);
    glm::vec3 U  = glm::normalize(glm::cross(up, n));
    glm::vec3 V  = glm::cross(n, U);
    glm::vec3 c  = n * plane.dist;
    float H = kHalfWorldSize;
    return {
        c - H*U - H*V,
        c + H*U - H*V,
        c + H*U + H*V,
        c - H*U + H*V,
    };
}

// ─────────────────────────────────────────────────────────────────────────────
// buildFacePolygon
// ─────────────────────────────────────────────────────────────────────────────

std::vector<glm::vec3> buildFacePolygon(const Face& face,
                                        const std::vector<Face>& allFaces)
{
    std::vector<glm::vec3> poly = buildInitialPolygon(face.plane);

    for (const Face& other : allFaces) {
        if (&other == &face) continue;
        poly = clipPolygonByPlane(poly, other.plane);
        if (poly.size() < 3) return {};
    }

    cleanupPolygon(poly);

    // Final safety pass
    if (poly.size() < 3) return {};

    return poly;
}

// ─────────────────────────────────────────────────────────────────────────────
// buildBrushMesh
// ─────────────────────────────────────────────────────────────────────────────

void buildBrushMesh(Brush& brush)
{
    brush.renderData.clear();
    brush.dirty = false;

    if (!brush.isValid()) return;

    // Work on a locally-transformed copy so we don't mutate brush.faces.
    const bool hasTransform = (brush.transform != glm::mat4(1.f));
    std::vector<Face> wsFaces = brush.faces;
    if (hasTransform)
        for (Face& f : wsFaces) f.applyTransform(brush.transform);

    auto nFaces = static_cast<uint32_t>(wsFaces.size());
    brush.renderData.faces.resize(nFaces);

    for (uint32_t fi = 0; fi < nFaces; ++fi) {
        const Face& face = wsFaces[fi];

        std::vector<glm::vec3> poly = buildFacePolygon(face, wsFaces);
        if (poly.size() < 3) continue;

        FaceMesh& fm  = brush.renderData.faces[fi];
        fm.material   = brush.faces[fi].material; // from original (untransformed) face
        fm.valid      = true;

        for (size_t vi = 0; vi < poly.size(); ++vi) {
            BrushVertex v;
            v.position  = poly[vi];
            v.normal    = face.plane.normal;
            v.uv        = face.uv.project(poly[vi]);
            v.faceIndex = fi;
            fm.vertices.push_back(v);
            brush.renderData.bounds.expand(poly[vi]);
        }

        // Triangle fan: (0,1,2), (0,2,3), …
        for (size_t vi = 1; vi + 1 < poly.size(); ++vi) {
            fm.indices.push_back(0);
            fm.indices.push_back(static_cast<uint32_t>(vi));
            fm.indices.push_back(static_cast<uint32_t>(vi + 1));
        }
    }

    brush.renderData.valid = true;

    // Rebuild topology from the fresh per-face meshes.
    buildTopology(brush);
}

} // namespace editor
