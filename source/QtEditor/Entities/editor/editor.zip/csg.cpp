// editor/csg.cpp
// ─────────────────────────────────────────────────────────────────────────────
// CSG Boolean subtraction.
//
// Terminology used in comments:
//   A  = the additive brush being carved into
//   S  = the subtractive brush doing the carving
//   "outside S" = on the front (positive) side of at least one of S's planes
//   "inside S"  = on the back  (negative) side of ALL of S's planes
// ─────────────────────────────────────────────────────────────────────────────

#include "csg.h"
#include "mesh_builder.h"  // clipPolygonByPlane, getFacePolygon
#include "raycast.h"
#include <algorithm>
#include <cmath>

namespace editor {

// ─────────────────────────────────────────────────────────────────────────────
// splitPolygon
//
// Sutherland-Hodgman style split that produces both halves simultaneously.
//
// Convention (matches the rest of the codebase):
//   front : distanceTo(P) > +kEpsilon   (outside / in front of plane)
//   back  : distanceTo(P) < -kEpsilon   (inside  / behind the plane)
//   on    : |distanceTo(P)| <= kEpsilon  (on the plane → added to BOTH sides)
// ─────────────────────────────────────────────────────────────────────────────

void splitPolygon(const std::vector<glm::vec3>& poly,
                  const Plane& plane,
                  std::vector<glm::vec3>& front,
                  std::vector<glm::vec3>& back)
{
    front.clear();
    back.clear();
    if (poly.size() < 3) return;

    for (size_t i = 0; i < poly.size(); ++i) {
        const glm::vec3& curr = poly[i];
        const glm::vec3& next = poly[(i + 1) % poly.size()];

        float dCurr = plane.distanceTo(curr);
        float dNext = plane.distanceTo(next);

        // Classify the current vertex.
        if (dCurr > kEpsilon)        { front.push_back(curr); }
        else if (dCurr < -kEpsilon)  { back.push_back(curr);  }
        else                         { front.push_back(curr); back.push_back(curr); }

        // If the edge straddles the plane, compute and emit the intersection.
        bool currFront = (dCurr >  kEpsilon);
        bool currBack  = (dCurr < -kEpsilon);
        bool nextFront = (dNext >  kEpsilon);
        bool nextBack  = (dNext < -kEpsilon);

        if ((currFront && nextBack) || (currBack && nextFront)) {
            float t = dCurr / (dCurr - dNext);
            glm::vec3 intersect = curr + t * (next - curr);
            front.push_back(intersect);
            back.push_back(intersect);
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// clipPolyOutsideBrush
//
// Recursive fragment-based clip.
//
// At each level we test the current fragment against subFaces[planeIdx]:
//   - The front half is definitively OUTSIDE the brush at this plane → emit.
//   - The back half is still potentially inside → recurse with planeIdx+1.
//
// A fragment that survives all planes is inside all half-spaces = inside the
// subtractive brush = should be removed → we just don't emit it.
//
// This is equivalent to the standard BSP inside/outside test but operating
// directly on polygons rather than a tree.
// ─────────────────────────────────────────────────────────────────────────────

void clipPolyOutsideBrush(const std::vector<glm::vec3>& poly,
                          const std::vector<Face>& subFaces,
                          size_t planeIdx,
                          std::vector<std::vector<glm::vec3>>& output)
{
    if (poly.size() < 3) return;

    // Processed all planes and the fragment is still here → it survived every
    // "are you inside me?" test, meaning it IS inside the subtractive brush.
    // Discard it (this is the volume being carved out).
    if (planeIdx >= subFaces.size()) return;

    std::vector<glm::vec3> front, back;
    splitPolygon(poly, subFaces[planeIdx].plane, front, back);

    // Front half: outside this plane → definitely outside the brush → keep.
    if (front.size() >= 3)
        output.push_back(front);

    // Back half: inside this plane → test remaining planes.
    if (back.size() >= 3)
        clipPolyOutsideBrush(back, subFaces, planeIdx + 1, output);
}

// ─────────────────────────────────────────────────────────────────────────────
// aabbsOverlap
// ─────────────────────────────────────────────────────────────────────────────

bool aabbsOverlap(const AABB& a, const AABB& b) noexcept
{
    return a.min.x <= b.max.x && a.max.x >= b.min.x
           && a.min.y <= b.max.y && a.max.y >= b.min.y
           && a.min.z <= b.max.z && a.max.z >= b.min.z;
}

// ─────────────────────────────────────────────────────────────────────────────
// triangulate
//
// Fan-triangulate a convex polygon and append the result into `face`.
// Handles UV computation from the face's projection.
// ─────────────────────────────────────────────────────────────────────────────

static void triangulatePoly(const std::vector<glm::vec3>& poly,
                            const glm::vec3& normal,
                            const UVProjection& uvProj,
                            uint32_t brushId,
                            uint32_t faceIdx,
                            const std::string& material,
                            bool isCap,
                            CSGFace& out)
{
    if (poly.size() < 3) return;

    uint32_t base = static_cast<uint32_t>(out.vertices.size());

    for (size_t vi = 0; vi < poly.size(); ++vi) {
        BrushVertex v;
        v.position  = poly[vi];
        v.normal    = normal;
        v.uv        = uvProj.project(poly[vi]);
        v.faceIndex = faceIdx;
        out.vertices.push_back(v);
    }

    for (size_t vi = 1; vi + 1 < poly.size(); ++vi) {
        out.indices.push_back(base);
        out.indices.push_back(base + static_cast<uint32_t>(vi));
        out.indices.push_back(base + static_cast<uint32_t>(vi + 1));
    }

    out.material       = material;
    out.sourceBrushId  = brushId;
    out.sourceFaceIdx  = faceIdx;
    out.isCap          = isCap;
    out.valid          = !out.vertices.empty();
}

// ─────────────────────────────────────────────────────────────────────────────
// subtractOneBrush
//
// Apply one subtractive brush S to one additive brush A.
// Modifies `result` in place (replaces its faces with the carved version).
//
// Steps:
//  1. For each existing face polygon in `result`, clip it outside S.
//     Surviving fragments become the new face list for that original face.
//  2. For each face of S, clip its polygon inside A and flip the winding.
//     These become "cap" faces that seal the carved volume.
// ─────────────────────────────────────────────────────────────────────────────

static void subtractOneBrush(BrushCSGResult& result,
                             const Brush& addBrush,
                             const Brush& subBrush)
{
    // Early-out: AABB overlap check.
    if (!aabbsOverlap(result.bounds, subBrush.renderData.bounds)) return;

    const std::vector<Face>& subFaces = subBrush.faces;

    // ── Step 1: clip each existing CSGFace against the outside of S ───────────

    std::vector<CSGFace> newFaces;
    newFaces.reserve(result.faces.size() * 2); // upper bound

    for (size_t fi = 0; fi < result.faces.size(); ++fi) {
        const CSGFace& srcFace = result.faces[fi];
        if (!srcFace.valid) continue;

        // Gather the current world-space polygon for this CSGFace.
        std::vector<glm::vec3> poly = srcFace.positions();
        if (poly.size() < 3) continue;

        // Collect all surviving (outside-S) fragments.
        std::vector<std::vector<glm::vec3>> fragments;
        clipPolyOutsideBrush(poly, subFaces, 0, fragments);

        // Re-triangulate each surviving fragment, preserving the source face's
        // normal and UV projection.
        // We recover the normal and UV from the original source brush face.
        const Face* srcBrushFace = addBrush.findFace(srcFace.sourceFaceIdx);
        glm::vec3     normal  = srcFace.vertices.empty()
                               ? glm::vec3(0.f, 1.f, 0.f)
                               : srcFace.vertices[0].normal;
        UVProjection  uvProj  = srcBrushFace ? srcBrushFace->uv : UVProjection{};

        for (size_t gi = 0; gi < fragments.size(); ++gi) {
            CSGFace newFace;
            triangulatePoly(fragments[gi], normal, uvProj,
                            srcFace.sourceBrushId, srcFace.sourceFaceIdx,
                            srcFace.material, srcFace.isCap, newFace);
            if (newFace.valid)
                newFaces.push_back(newFace);
        }
    }

    // ── Step 2: cap faces from S clipped to inside A ──────────────────────────
    //
    // Each face of S contributes a cap polygon at the intersection boundary.
    // We flip the winding (std::reverse) so its normal points inward (into the
    // carved void, which is what the player will see from inside the hole).

    const std::vector<Face>& addFaces = addBrush.faces;

    for (size_t si = 0; si < subFaces.size(); ++si) {
        // Get the world-space polygon of this subtractive face.
        std::vector<glm::vec3> capPoly = getFacePolygon(subBrush,
                                                        static_cast<uint32_t>(si));
        if (capPoly.size() < 3) continue;

        // Flip winding so the normal points INTO the carved volume.
        std::reverse(capPoly.begin(), capPoly.end());
        glm::vec3 capNormal = -subFaces[si].plane.normal; // flipped

        // Clip to the INSIDE of the additive brush (keep only the part of the
        // cap that is actually within A's volume).
        // clipPolygonByPlane keeps the back side (dist <= kEpsilon = inside).
        for (size_t ai = 0; ai < addFaces.size(); ++ai) {
            capPoly = clipPolygonByPlane(capPoly, addFaces[ai].plane);
            if (capPoly.size() < 3) break;
        }
        if (capPoly.size() < 3) continue;

        CSGFace capFace;
        triangulatePoly(capPoly, capNormal, subFaces[si].uv,
                        subBrush.id, static_cast<uint32_t>(si),
                        subFaces[si].material, /*isCap=*/true, capFace);
        if (capFace.valid)
            newFaces.push_back(capFace);
    }

    // Recompute bounds from surviving geometry.
    result.bounds = AABB{};
    for (size_t fi = 0; fi < newFaces.size(); ++fi) {
        for (size_t vi = 0; vi < newFaces[fi].vertices.size(); ++vi)
            result.bounds.expand(newFaces[fi].vertices[vi].position);
    }

    result.faces = newFaces;
}

// ─────────────────────────────────────────────────────────────────────────────
// buildLevelCSG
// ─────────────────────────────────────────────────────────────────────────────

LevelCSGData buildLevelCSG(
    const std::vector<const Brush*>& additiveBrushes,
    const std::vector<const Brush*>& subtractiveBrushes)
{
    LevelCSGData data;

    for (size_t ai = 0; ai < additiveBrushes.size(); ++ai) {
        const Brush* addBrush = additiveBrushes[ai];
        if (!addBrush || !addBrush->renderData.valid) continue;

        // Seed the result from the brush's raw renderData (no subtractions yet).
        BrushCSGResult result;
        result.brushId = addBrush->id;
        result.bounds  = addBrush->renderData.bounds;

        const uint32_t nFaces = static_cast<uint32_t>(addBrush->faces.size());
        result.faces.reserve(nFaces);

        for (uint32_t fi = 0; fi < nFaces; ++fi) {
            const FaceMesh& fm = addBrush->renderData.faces[fi];
            if (!fm.valid) continue;

            CSGFace csgFace;
            csgFace.material      = fm.material;
            csgFace.sourceBrushId = addBrush->id;
            csgFace.sourceFaceIdx = fi;
            csgFace.isCap         = false;
            csgFace.valid         = true;

            // Copy vertices and indices directly — no re-triangulation needed yet.
            for (size_t vi = 0; vi < fm.vertices.size(); ++vi)
                csgFace.vertices.push_back(fm.vertices[vi]);
            for (size_t ii = 0; ii < fm.indices.size(); ++ii)
                csgFace.indices.push_back(fm.indices[ii]);

            result.faces.push_back(csgFace);
        }

        // Apply every subtractive brush in sequence.
        for (size_t si = 0; si < subtractiveBrushes.size(); ++si) {
            const Brush* subBrush = subtractiveBrushes[si];
            if (!subBrush || !subBrush->renderData.valid) continue;
            subtractOneBrush(result, *addBrush, *subBrush);
        }

        result.valid = !result.faces.empty();
        data.results[addBrush->id] = result;
    }

    data.valid = true;
    return data;
}

} // namespace editor