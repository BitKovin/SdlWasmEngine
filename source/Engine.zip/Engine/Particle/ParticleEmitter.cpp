#include "ParticleEmitter.h"

#include "../MathHelper.hpp"
#include "../ShaderManager.h"
#include "../FrustrumCull.hpp"
#include "../BoundingSphere.hpp"
#include "../Renderer/Renderer.h"
#include "../BSP/Quake3Bsp.h"

#include <BgfxStateManager.h>
#include <Renderer/Abstractions/ViewIdManager.h>
#include <Profiling/ResourceStatistics.hpp>

// Static member definitions
bgfx::VertexBufferHandle ParticleEmitter::s_billboardVbh   = BGFX_INVALID_HANDLE;
bgfx::IndexBufferHandle  ParticleEmitter::s_billboardIbh   = BGFX_INVALID_HANDLE;
bgfx::VertexLayout       ParticleEmitter::s_billboardLayout = {};

// Helpers
mat4 GetWorldMatrix(const Particle& particle)
{
    return translate(particle.position) * MathHelper::GetRotationMatrix(particle.globalRotation) * scale(vec3(particle.Size));
}

// Spawn / Update
void ParticleEmitter::SpawnParticles(int num)
{
    std::lock_guard<std::recursive_mutex> lock(particlesMutex);
    for (int i = 0; i < num; i++) {
        Particle particle = GetNewParticle();
        particle.deathTime *= i + 1;
        AddParticle(particle);
    }
}

void ParticleEmitter::Update(float deltaTime)
{
    if (destroyed)
        return;

    std::lock_guard<std::recursive_mutex> lock(particlesMutex);
    emitterTime += deltaTime;
    elapsedTime += deltaTime;
    if (elapsedTime > Duration)
        Emitting = false;

    const float spawnInterval = (SpawnRate > 0.0f) ? (1.0f / SpawnRate) : 0.0f;

    if (SpawnRate > 0.0f && Emitting && spawnInterval > 0.0f)
    {
        while (elapsedTime >= spawnInterval)
        {
            Particles.push_back(GetNewParticle());
            elapsedTime -= spawnInterval;
        }
    }

    for (auto& p : Particles)
        p.lifeTime += deltaTime;

    Particles.erase(
        std::remove_if(Particles.begin(), Particles.end(),
            [](const Particle& p) { return p.lifeTime >= p.deathTime; }),
        Particles.end());

    if (MaxParticles > 0 && Particles.size() > MaxParticles)
    {
        const size_t excess = Particles.size() - MaxParticles;
        Particles.erase(
            Particles.begin(),
            Particles.begin() + static_cast<std::ptrdiff_t>(excess));
    }

    for (auto& p : Particles)
        p = UpdateParticle(p, deltaTime);

    if (!Emitting && Particles.empty())
        destroyed = true;
}

// InitBilboardVaoIfNeeded
void ParticleEmitter::InitBilboardVaoIfNeeded()
{
    if (bgfx::isValid(s_billboardVbh)) return;

    // Exact match to shader $input — this is what the official bgfx example does
    s_billboardLayout.begin()
        .add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
        .add(bgfx::Attrib::TexCoord0, 2, bgfx::AttribType::Float)
        .end();

    struct BillboardVertex {
        float x, y, z;
        float u, v;
    };

    BillboardVertex vertices[4] = {
        {-0.5f, -0.5f, 0.0f, 0.0f, 1.0f},
        { 0.5f, -0.5f, 0.0f, 1.0f, 1.0f},
        { 0.5f,  0.5f, 0.0f, 1.0f, 0.0f},
        {-0.5f,  0.5f, 0.0f, 0.0f, 0.0f}
    };

    uint16_t indices[6] = { 0, 1, 2, 2, 3, 0 };

    s_billboardVbh = bgfx::createVertexBuffer(bgfx::copy(vertices, sizeof(vertices)), s_billboardLayout);
    s_billboardIbh = bgfx::createIndexBuffer(bgfx::copy(indices, sizeof(indices)));

    if (bgfx::isValid(s_billboardVbh))
    {
        ResourceStatistics::Instance().registerResource(
            ResourceType::VertexBuffer, s_billboardVbh.idx, sizeof(vertices), "Particle Billboard VB");
    }
    if (bgfx::isValid(s_billboardIbh))
    {
        ResourceStatistics::Instance().registerResource(
            ResourceType::IndexBuffer, s_billboardIbh.idx, sizeof(indices), "Particle Billboard IB");
    }
}

void ParticleEmitter::DestroyBillboardVao()
{

	if (bgfx::isValid(s_billboardVbh))
    {
        ResourceStatistics::Instance().unregisterResource(ResourceType::VertexBuffer, s_billboardVbh.idx);
        bgfx::destroy(s_billboardVbh);
        s_billboardVbh = BGFX_INVALID_HANDLE;
    }

	if (bgfx::isValid(s_billboardIbh))
    {
        ResourceStatistics::Instance().unregisterResource(ResourceType::IndexBuffer, s_billboardIbh.idx);
        bgfx::destroy(s_billboardIbh);
        s_billboardIbh = BGFX_INVALID_HANDLE;
    }

}

// PreFinalize - parallel, pure CPU math + BSP lightvol reads, no OwnerEntity involved.
void ParticleEmitter::PreFinalize()
{

    {
        std::lock_guard<std::recursive_mutex> lock(particlesMutex);
        finalizedParticles = Particles;
    }

    const vec3 cameraPosition = Camera::finalizedPosition;
    const vec3 cameraRotation = Camera::finalizedRotation;
    const vec3 cameraForward = MathHelper::GetForwardVector(cameraRotation);
    const vec3 cameraRight = MathHelper::GetRightVector(cameraRotation);
    const vec3 cameraUp = MathHelper::GetUpVector(cameraRotation);

    const int cameraC = Level::Current->BspData.FindClusterAtPosition(cameraPosition);

    preFinalizedInstances.clear();

    if (DepthSorting)
    {
        std::vector<std::pair<float, InstanceData>> visible;
        visible.reserve(finalizedParticles.size());

        for (const auto& particle : finalizedParticles)
        {
            if (!Camera::frustum.IsSphereVisible(particle.position, particle.Size))
                continue;

            int targetC = Level::Current->BspData.FindClusterAtPosition(particle.position);
            if (!Level::Current->BspData.IsClusterVisible(cameraC, targetC))
                continue;

            mat4x4 world;
            if (particle.UseWorldRotation)
                world = GetWorldMatrix(particle);
            else
                world = MathHelper::CreateBillboardMatrix(
                    particle.position, cameraPosition,
                    cameraForward, cameraRight, cameraUp,
                    vec3(particle.Size), particle.rotation);

            InstanceData data{};
            data.model[0] = world[0];  // column 0
            data.model[1] = world[1];
            data.model[2] = world[2];
            data.model[3] = world[3];
            data.Color = particle.Color * (ParticleLighting ? vec4(GetLightForParticle(particle), 1.0f) : vec4(1.0f));
            data.Color.a *= particle.Transparency;

            float depth = glm::dot(cameraForward, particle.position - cameraPosition);
            visible.emplace_back(depth, std::move(data));
        }

        if (!visible.empty())
        {
            std::sort(visible.begin(), visible.end(),
                [](const auto& a, const auto& b) { return a.first > b.first; });

            preFinalizedInstances.reserve(visible.size());
            for (auto& v : visible)
                preFinalizedInstances.push_back(std::move(v.second));
        }
    }
    else
    {
        preFinalizedInstances.reserve(finalizedParticles.size());
        for (const auto& particle : finalizedParticles)
        {

            if (ParticleCulling)
            {
                if (!Camera::frustum.IsSphereVisible(particle.position, particle.Size))
                    continue;

                int targetC = Level::Current->BspData.FindClusterAtPosition(particle.position);
                if (!Level::Current->BspData.IsClusterVisible(cameraC, targetC))
                    continue;
            }


            mat4x4 world;
            if (particle.UseWorldRotation)
                world = GetWorldMatrix(particle);
            else
                world = MathHelper::CreateBillboardMatrix(
                    particle.position, cameraPosition,
                    cameraForward, cameraRight, cameraUp,
                    vec3(particle.Size), particle.rotation);

            InstanceData data{};
            data.model[0] = world[0];  // column 0
            data.model[1] = world[1];
            data.model[2] = world[2];
            data.model[3] = world[3];
            data.Color = particle.Color * vec4(GetLightForParticle(particle), 1.0f);
            data.Color.a *= particle.Transparency;
            preFinalizedInstances.push_back(std::move(data));
        }

    }

}

// FinalizeFrameData - main thread: resolve the texture and commit onto drawCommand.
void ParticleEmitter::FinalizeFrameData()
{
    if (savedTextureName != texture)
    {
        savedTexture = AssetRegistry::GetTextureFromFile(texture);
        savedTextureName = texture;
    }

    drawCommand.Instances = std::move(preFinalizedInstances);
    drawCommand.ResolvedTexture = savedTexture;
    drawCommand.IsDecal = isDecal;
    drawCommand.PixelShader = PixelShader;
    drawCommand.BlendMode = BlendMode;

    SyncCommandFlags(drawCommand);
}

// GetLightForParticle
vec3 ParticleEmitter::GetLightForParticle(const Particle& particle)
{
    if (particle.UseWorldRotation == false)
    {
        auto light = Level::Current->BspData.GetLightvolColorPoint(MathHelper::TransformVector(particle.position, RelativeTransform) * MAP_SCALE);
        return (light.ambientColor + light.directColor) * 1.0f;
    }

    vec3 normal = MathHelper::GetForwardVector(particle.globalRotation);

    auto light = Level::Current->BspData.GetLightvolColorPoint((MathHelper::TransformVector(particle.position, RelativeTransform) + normal) * MAP_SCALE) * 1.0f;

    float dirFactor = 1.0f;

    return light.ambientColor + light.directColor * dirFactor;
}
