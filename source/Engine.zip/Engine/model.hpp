#ifndef MODEL_HPP
#define MODEL_HPP
#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

#include "malloc_override.h"

#include "glm.h"

#include <unordered_map>
#include <vector>

#include "utils.hpp"

#include "VertexData.h"

namespace roj
{

	class LoaderGlobalParams
	{
	public:

		static std::string MeshNameLimit;
		static float Size;

	private:

	};

	

	struct MeshTexture
	{
		aiTextureType type; std::string src;
	};

	struct Mesh
	{
		bgfx::VertexBufferHandle vbh = BGFX_INVALID_HANDLE;
		bgfx::IndexBufferHandle  ibh = BGFX_INVALID_HANDLE;

		bgfx::VertexLayout layout;

		std::vector<MeshTexture> textures; // usually uniforms + sampler handles

		std::vector<VertexData> vertices;
		std::vector<uint32_t> indices;

		uint32_t numIndices = 0;
	};

	template<typename mesh_t>
	struct ModelType;

	struct SkinnedMesh; struct SkinnedModel;
	template<>
	struct ModelType<SkinnedMesh> { using type = SkinnedModel; };

	template<>
	struct ModelType<Mesh> { using type = std::vector<Mesh>; };

	template<typename mesh_t = Mesh>
	class ModelLoader
	{
	public:
		using model_t = typename ModelType<mesh_t>::type;
	private:
		Assimp::Importer m_import;
		model_t m_model;
		std::vector<MeshTexture> m_texCache;
		std::string m_infoLog;
		std::string m_relativeDir;

		std::vector<glm::vec3> vertexPositions;
		std::unordered_map<glm::vec3, glm::vec3> vertexNormals; // position and normal
		std::unordered_map<glm::vec3, float> vertexNormalsN; // position and normal num

		std::string m_lastLoadedPath;
		const aiScene* m_cachedScene;

	private:

		

		void resetLoader();
		void processNode(aiNode* node, const aiScene* scene);
		void processNodeVertices(aiNode* node, const aiScene* scene);
		mesh_t processMesh(aiMesh* mesh, const aiScene* scene);
		std::vector<VertexData>  getMeshVertices(aiMesh* mesh);
		std::vector<MeshTexture> getMeshTextures(aiMaterial* material, const aiScene* scene);
		std::vector<MeshTexture> loadTextureMap(aiMaterial* mat, aiTextureType type, const aiScene* scene);

		void LoadTextureFromScene(const aiTexture* texture);

	public:

		bool SkipVisual = false;

		// Parses geometry/textures fully (unlike SkipVisual) but never calls
		// bgfx - vbh/ibh/shadow volumes and embedded textures are left for
		// the caller to upload later. Set this when load() is running on a
		// thread that doesn't own bgfx (see AssetRegistry's Loader thread).
		bool DeferGPUUpload = false;

		ModelLoader() = default;
		bool load(const std::string& path);
		model_t& get();
		const std::string& getInfoLog();
	};

	template<typename mesh_t>
	typename ModelLoader<mesh_t>::model_t& ModelLoader<mesh_t>::get()
	{
		return m_model;
	}

	template<typename mesh_t>
	const std::string& ModelLoader<mesh_t>::getInfoLog()
	{
		return m_infoLog;
	}

	template<typename mesh_t>
	std::vector<MeshTexture> ModelLoader<mesh_t>::getMeshTextures(aiMaterial* material, const aiScene* scene)
	{
		std::vector<MeshTexture> textures;

		std::vector<MeshTexture> diffuseMaps = loadTextureMap(material, aiTextureType_BASE_COLOR, scene);
		textures.insert(textures.end(), diffuseMaps.begin(), diffuseMaps.end());

		std::vector<MeshTexture> emissiveMaps = loadTextureMap(material, aiTextureType_EMISSIVE, scene);
		textures.insert(textures.end(), emissiveMaps.begin(), emissiveMaps.end());

		std::vector<MeshTexture> emissiveColorMaps = loadTextureMap(material, aiTextureType_EMISSION_COLOR, scene);
		textures.insert(textures.end(), emissiveColorMaps.begin(), emissiveColorMaps.end());

		std::vector<MeshTexture> specularMaps = loadTextureMap(material, aiTextureType_SPECULAR, scene);
		textures.insert(textures.end(), specularMaps.begin(), specularMaps.end());

		std::vector<MeshTexture> normalMaps = loadTextureMap(material, aiTextureType_NORMALS, scene);
		textures.insert(textures.end(), normalMaps.begin(), normalMaps.end());

		std::vector<MeshTexture> heightMaps = loadTextureMap(material, aiTextureType_HEIGHT, scene);
		textures.insert(textures.end(), heightMaps.begin(), heightMaps.end());
		return textures;
	}

	template<typename mesh_t>
	std::vector<roj::MeshTexture> ModelLoader<mesh_t>::loadTextureMap(aiMaterial* mat, aiTextureType type, const aiScene* scene)
	{
		std::vector<MeshTexture> textures;

		for (uint32_t i = 0; i < mat->GetTextureCount(type); i++)
		{
			aiString texSrc;
			mat->GetTexture(type, i, &texSrc);

			std::string str = texSrc.C_Str();

			str = str.substr(1, str.size() - 1);

			int id = std::stoi(str);


			std::string fileName = scene->mTextures[id]->mFilename.C_Str();
			std::string fileExtension = scene->mTextures[id]->achFormatHint;

			textures.emplace_back(type, fileName + "." + fileExtension);

			const aiTexture* tex = scene->GetEmbeddedTexture(fileName.c_str());


			// If the texture is embedded (starts with '*')
			if (tex != nullptr)
			{
				//LoadTextureFromScene(tex);

			}

		}

		

		return textures;
	}

	template<typename mesh_t>
	void ModelLoader<mesh_t>::resetLoader()
	{
		m_texCache.clear();
		m_model.clear();
		m_infoLog.clear();
		m_relativeDir.clear();

		vertexPositions.clear();
		vertexNormals.clear();
		vertexNormalsN.clear();

	}
}

#endif //-MODEL_HPP