#pragma once

#include "malloc_override.h"

#include <SDL2/SDL_video.h>

#include "Camera.h"
#include "Input.h"

#include "Level.hpp"

#include "ShaderManager.h"

#include "ThreadPool.h"

#include <thread>

#include "ImGuiEngineImpl.h"

#include "UI/UiViewport.hpp"

#include "MapParser.h"

#include "Renderer/Renderer.h"
#include "SaveSystem/GameSaveSystem.h"

#include <FileSystem/FileSystem.h>

class RmlUiContext;

class EngineMain
{
private:



public:

    GameSaveData pendingRestoreSaveData;// for platforms like android we just save and reload game when minimized

	std::shared_ptr<IFileSystem> FileSystem;

    Renderer* MainRenderer;

	SDL_Window* Window = nullptr;

	static EngineMain* MainInstance;

    static UiViewport Viewport;

    ivec2 ScreenSize = ivec2();

    bool Paused = false;

    bool DebugUiEnabled = false;

    int LoadingFrames = 0;

    unsigned long frame = 0;

	bool SimulatingGameTicks = false;
    bool SimulatingPreciseGameTicks = false;

	RenderTexture* UiRenderTexture = nullptr;
    RenderTexture* UiRenderTextureStencil = nullptr;
    Framebuffer* UiFrameBuffer = nullptr;

	RenderTexture* FinalFrameRenderTexture = nullptr;

	RmlUiContext* RmlContext = nullptr;

	EngineMain(SDL_Window* window)
	{
		Window = window;
	}
    ~EngineMain();


    std::map<std::string, std::vector<std::string>> Arguments;

    void UpdateScreenSize();

    ThreadPool* MainThreadPool = nullptr;
    ThreadPool* GameUpdateSingleThreadPool = nullptr;

    void ToggleFullscreen();

    void initGame();

    void InitInputs();



    void Init(const std::vector<std::string> args = {});

    static std::map<std::string, std::vector<std::string>> ParseCommands(const std::vector<std::string>& args);

    void FinishFrame();

    // Toggle asynchronous GameUpdate.
    bool asyncGameUpdate = true;

    // Main game loop.
    void MainLoop();

	void SimulateGameTick();
	void SimulateGameTicksForTime(float timeToSimulate);
    void SimulateGameTicksForTimeCombinedPrecision(float timeToSimulate);

    void GameUpdate();

    void Render();

	void ForceUpdateScreenSize();

    void FinishRender();

};