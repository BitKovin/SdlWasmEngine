#include "CompositeNodes.h"

SequenceNode::SequenceNode() : CompositeNode("Sequence", "SequenceNode") {}

void SequenceNode::OnStart(BehaviorTreeContext& context) 
{

    //currentChildIndex_ = 0;
}

void SequenceNode::OnStop(BehaviorTreeContext& context)
{
    currentChildIndex_ = 0;
    TreeNode::OnStop(context);
}

NodeStatus SequenceNode::Execute(BehaviorTreeContext& context) {
    // Start from current child index (for resuming after Running)
    for (size_t i = currentChildIndex_; i < children_.size(); ++i) {
        auto& child = children_[i];

        bool startingNode = child->GetStatus() != NodeStatus::Running;

        NodeStatus childStatus = child->TickNode(context);



        if (context.reachedTask)
        {
            if (childStatus == NodeStatus::Success || childStatus == NodeStatus::Failure)
            {
                child->SetStatus(NodeStatus::Idle);

                currentChildIndex_ = i + 1;
                if (currentChildIndex_ == children_.size())
                {
                    break;
                }
                    

                return NodeStatus::Running;
            }
            else if ((childStatus == NodeStatus::Running)) 
            
            {
                currentChildIndex_ = i;

                return NodeStatus::Running;
            }
        }
        else
        {
			if (childStatus == NodeStatus::Failure && false)
			{
				// UE: on failure, sequence fails immediately; next tick should start from first child again
				currentChildIndex_ = 0;
				child->SetStatus(NodeStatus::Idle);
				return NodeStatus::Failure;
			}
        }



        // Success: advance to next child; next child will OnStart on first Tick
    }


    // All children succeeded. Keep returning Success until external flow changes (e.g., aborts or reset).
    // Next evaluation should begin from first child again.
    currentChildIndex_ = 0;
    return NodeStatus::Success;
}

void SequenceNode::OnReset() {
    TreeNode::OnReset();
    currentChildIndex_ = 0;
    for (auto& child : children_) {
        child->OnReset();
    }
}

void SequenceNode::Abort(BehaviorTreeContext& context) {
    // Abort current running child
    if (currentChildIndex_ < children_.size()) {
        children_[currentChildIndex_]->Abort(context);
    }
    TreeNode::Abort(context);
}

json SequenceNode::SaveState() const {
    auto j = TreeNode::SaveState();
    j["currentChildIndex"] = currentChildIndex_;
    return j;
}

void SequenceNode::LoadState(const json& j) {
    TreeNode::LoadState(j);
    if (j.contains("currentChildIndex")) {
        currentChildIndex_ = j["currentChildIndex"].get<size_t>();
    }
}

MultiExecSequenceNode::MultiExecSequenceNode() : CompositeNode("Multi Execution Sequence", "MultiExecSequenceNode") {}
void MultiExecSequenceNode::OnStart(BehaviorTreeContext& context)
{

    //currentChildIndex_ = 0;
}

void MultiExecSequenceNode::OnStop(BehaviorTreeContext& context)
{
    currentChildIndex_ = 0;
    TreeNode::OnStop(context);
}

NodeStatus MultiExecSequenceNode::Execute(BehaviorTreeContext& context) {

    for (size_t i = 0; i < children_.size(); ++i) {
        auto& child = children_[i];

        bool startingNode = child->GetStatus() != NodeStatus::Running;

        NodeStatus childStatus = child->TickNode(context);
    }

    return NodeStatus::Success;

}

void MultiExecSequenceNode::OnReset() {
    TreeNode::OnReset();
    currentChildIndex_ = 0;
    for (auto& child : children_) {
        child->OnReset();
    }
}

void MultiExecSequenceNode::Abort(BehaviorTreeContext& context) {
    // Abort current running child
    if (currentChildIndex_ < children_.size()) {
        children_[currentChildIndex_]->Abort(context);
    }
    TreeNode::Abort(context);
}

json MultiExecSequenceNode::SaveState() const {
    auto j = TreeNode::SaveState();
    return j;
}

void MultiExecSequenceNode::LoadState(const json& j) {
    TreeNode::LoadState(j);
}

SelectorNode::SelectorNode() : CompositeNode("Selector", "SelectorNode") {}

void SelectorNode::OnStart(BehaviorTreeContext& context) {
    currentChildIndex_ = 0;
}

NodeStatus SelectorNode::Execute(BehaviorTreeContext& context) 
{

    size_t currentExecutedChild = -1;

    for (size_t i = currentChildIndex_; i < children_.size(); ++i) {
        auto& child = children_[i];
        NodeStatus childStatus = child->TickNode(context);

        if (context.hasToFinishDecorator)
        {

            currentChildIndex_ = i;

            return NodeStatus::Running;
        }

        if (childStatus == NodeStatus::Running) 
        {
            currentChildIndex_ = 0;
            
            return NodeStatus::Running;
        }
        else if (childStatus == NodeStatus::Success) {
            // UE: on success, selector succeeds immediately; next tick should start from first child again
            currentChildIndex_ = 0;

            if (previousExecutedChild != i)
            {
                if(previousExecutedChild>=0)
                    children_[previousExecutedChild]->OnStop(context);
            }

            previousExecutedChild = i;
            return NodeStatus::Success;
        }
    }

    previousExecutedChild = -1;

    // All children failed
    currentChildIndex_ = 0;
    return NodeStatus::Failure;

}

void SelectorNode::OnReset() {
    TreeNode::OnReset();
    currentChildIndex_ = 0;
    for (auto& child : children_) {
        child->OnReset();
    }
}

void SelectorNode::Abort(BehaviorTreeContext& context) {
    // Abort current running child
    if (currentChildIndex_ < children_.size()) {
        children_[currentChildIndex_]->Abort(context);
    }
    TreeNode::Abort(context);
}

json SelectorNode::SaveState() const {
    auto j = TreeNode::SaveState();
    j["currentChildIndex"] = currentChildIndex_;
    return j;
}

void SelectorNode::LoadState(const json& j) {
    TreeNode::LoadState(j);
    if (j.contains("currentChildIndex")) {
        currentChildIndex_ = j["currentChildIndex"].get<size_t>();
    }
}