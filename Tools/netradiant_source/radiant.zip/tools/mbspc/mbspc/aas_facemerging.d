tools/mbspc/mbspc/aas_facemerging.o: tools/mbspc/mbspc/aas_facemerging.c \
 tools/mbspc/mbspc/qbsp.h tools/mbspc/mbspc/l_cmd.h libs/bytebool.h \
 tools/mbspc/mbspc/l_math.h tools/mbspc/mbspc/l_poly.h \
 tools/mbspc/mbspc/l_threads.h tools/mbspc/mbspc/../botlib/l_script.h \
 tools/mbspc/mbspc/l_bsp_ent.h tools/mbspc/mbspc/q2files.h \
 tools/mbspc/mbspc/l_mem.h tools/mbspc/mbspc/l_utils.h \
 tools/mbspc/mbspc/l_log.h tools/mbspc/mbspc/l_qfiles.h \
 tools/mbspc/mbspc/../qcommon/unzip.h \
 tools/mbspc/mbspc/../botlib/aasfile.h tools/mbspc/mbspc/aas_create.h
