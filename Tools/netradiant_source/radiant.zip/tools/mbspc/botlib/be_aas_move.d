tools/mbspc/botlib/be_aas_move.o: tools/mbspc/botlib/be_aas_move.c \
 tools/mbspc/botlib/../qcommon/q_shared.h \
 tools/mbspc/botlib/../qcommon/q_platform.h libs/bytebool.h \
 tools/mbspc/botlib/../qcommon/surfaceflags.h \
 tools/mbspc/botlib/l_memory.h tools/mbspc/botlib/l_script.h \
 tools/mbspc/botlib/l_precomp.h tools/mbspc/botlib/l_struct.h \
 tools/mbspc/botlib/l_libvar.h tools/mbspc/botlib/aasfile.h \
 tools/mbspc/botlib/botlib.h tools/mbspc/botlib/be_aas.h \
 tools/mbspc/botlib/be_aas_funcs.h tools/mbspc/botlib/be_aas_def.h \
 tools/mbspc/botlib/be_aas_bsp.h tools/mbspc/botlib/be_aas_sample.h \
 tools/mbspc/botlib/be_aas_move.h
