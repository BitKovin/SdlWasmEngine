/*
   Copyright (C) 1999-2006 Id Software, Inc. and contributors.
   For a list of contributors, see the accompanying CONTRIBUTORS file.

   This file is part of GtkRadiant.

   GtkRadiant is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   GtkRadiant is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with GtkRadiant; if not, write to the Free Software
   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

// cmdlib.h

#ifndef __CMDLIB__
#define __CMDLIB__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <time.h>
#include <stdarg.h>

#ifdef _MSC_VER
	#ifdef NDEBUG                           // Don't show in a Release build
		#pragma warning(disable : 4305)     // truncate from double to float
		#pragma warning(disable : 4244)     // conversion from double to float
		#pragma warning(disable : 4018)     // signed/unsigned mismatch
	#endif
#endif

#ifdef _MSC_VER
	#pragma intrinsic( memset, memcpy )
#endif

#include "bytebool.h"

#ifdef PATH_MAX
#define MAX_OS_PATH     PATH_MAX
#else
#define MAX_OS_PATH     1024
#endif
#define MEM_BLOCKSIZE 4096

/*
   extern	qboolean verbose;
   #define SYS_VRB 0 // verbose support (on/off)
   #define SYS_STD 1 // standard print level
   #define SYS_WRN 2 // warnings
   #define SYS_ERR 3 // error
 */

#define SAFE_MALLOC
#ifdef SAFE_MALLOC
void *safe_malloc( size_t size );
void *safe_malloc_info( size_t size, char* info );
#else
#define safe_malloc( a ) malloc( a )
#endif /* SAFE_MALLOC */

// set these before calling CheckParm
extern int myargc;
extern char **myargv;

static inline char *strLower( char *string ){
	for( char *in = string; *in; ++in )
		*in = tolower( *in );
	return string;
}
int Q_strncasecmp( const char *s1, const char *s2, int n );
int Q_strcasecmp( const char *s1, const char *s2 );
int Q_stricmp( const char *s1, const char *s2 );
void Q_getwd( char *out );

int Q_filelength( FILE *f );
int FileTime( const char *path );

void    Q_mkdir( const char *path );

extern char qdir[1024];
extern char gamedir[1024];
extern char writedir[1024];
extern char    *moddirparam;
void SetQdirFromPath( const char *path );
char *ExpandArg( const char *path );    // from cmd line
char *ExpandPath( const char *path );   // from scripts
char *ExpandGamePath( const char *path );
char *ExpandPathAndArchive( const char *path );
void ExpandWildcards( int *argc, char ***argv );


double I_FloatTime( void );

int     CheckParm( const char *check );

FILE    *SafeOpenWrite( const char *filename );
FILE    *SafeOpenRead( const char *filename );
void    SafeRead( FILE *f, void *buffer, int count );
void    SafeWrite( FILE *f, const void *buffer, int count );

int     LoadFile( const char *filename, void **bufferptr );
int   LoadFileBlock( const char *filename, void **bufferptr );
int     TryLoadFile( const char *filename, void **bufferptr );
void    SaveFile( const char *filename, const void *buffer, int count );
qboolean    FileExists( const char *filename );

void    DefaultExtension( char *path, const char *extension );
void    DefaultPath( char *path, const char *basepath );
void    StripFilename( char *path );
void    StripExtension( char *path );

void    ExtractFilePath( const char *path, char *dest );
void    ExtractFileBase( const char *path, char *dest );
void    ExtractFileExtension( const char *path, char *dest );

int     ParseNum( const char *str );

//void Sys_Printf (const char *text, ...);
//void Sys_FPrintf (int flag, const char *text, ...);
//void	Error( const char *error, ... );

short   BigShort( short l );
short   LittleShort( short l );
int     BigLong( int l );
int     LittleLong( int l );
float   BigFloat( float l );
float   LittleFloat( float l );


char *COM_Parse( char *data );

extern char com_token[1024];
extern qboolean com_eof;

char *copystring( const char *s );


void CRC_Init( unsigned short *crcvalue );
void CRC_ProcessByte( unsigned short *crcvalue, byte data );
unsigned short CRC_Value( unsigned short crcvalue );

void    CreatePath( const char *path );
void    QCopyFile( const char *from, const char *to );

extern qboolean archive;
extern char archivedir[1024];

// sleep for the given amount of milliseconds
void Sys_Sleep( int n );

// for compression routines
typedef struct
{
	byte    *data;
	int count;
} cblock_t;

extern char game[64];

#endif
