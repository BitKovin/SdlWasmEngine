radiant/layerswindow.o: radiant/layerswindow.cpp radiant/layerswindow.h \
 libs/layers.h libs/scenelib.h include/iscenegraph.h \
 libs/generic/constant.h libs/signal/signalfwd.h include/modulesystem.h \
 libs/generic/static.h libs/debugging/debugging.h \
 libs/stream/textstream.h include/itextstream.h libs/generic/arrayrange.h \
 include/iselection.h libs/generic/callback.h libs/generic/functional.h \
 libs/math/vectorfwd.h libs/math/aabb.h libs/math/matrix.h \
 libs/math/vector.h libs/generic/vector.h libs/math/pi.h \
 libs/math/plane.h libs/transformlib.h libs/math/quaternion.h \
 libs/generic/reference.h libs/container/stack.h libs/memory/allocator.h \
 libs/generic/object.h libs/typesystem.h libs/generic/referencecounted.h \
 libs/string/string.h libs/traverselib.h libs/undolib.h include/iundo.h \
 include/mapfile.h libs/container/container.h \
 C:/msys64/mingw64/include/QtWidgets/QApplication \
 C:/msys64/mingw64/include/QtWidgets/qapplication.h \
 C:/msys64/mingw64/include/QtWidgets/QTreeWidget \
 C:/msys64/mingw64/include/QtWidgets/qtreewidget.h \
 C:/msys64/mingw64/include/QtWidgets/QHeaderView \
 C:/msys64/mingw64/include/QtWidgets/qheaderview.h \
 C:/msys64/mingw64/include/QtWidgets/QBoxLayout \
 C:/msys64/mingw64/include/QtWidgets/qboxlayout.h \
 C:/msys64/mingw64/include/QtWidgets/QToolButton \
 C:/msys64/mingw64/include/QtWidgets/qtoolbutton.h \
 C:/msys64/mingw64/include/QtGui/QDropEvent \
 C:/msys64/mingw64/include/QtGui/qevent.h \
 C:/msys64/mingw64/include/QtCore/QMimeData \
 C:/msys64/mingw64/include/QtCore/qmimedata.h \
 C:/msys64/mingw64/include/QtGui/QIcon \
 C:/msys64/mingw64/include/QtGui/qicon.h \
 C:/msys64/mingw64/include/QtWidgets/QMenu \
 C:/msys64/mingw64/include/QtWidgets/qmenu.h \
 C:/msys64/mingw64/include/QtWidgets/QInputDialog \
 C:/msys64/mingw64/include/QtWidgets/qinputdialog.h \
 C:/msys64/mingw64/include/QtCore/QTimer \
 C:/msys64/mingw64/include/QtCore/qtimer.h radiant/map.h \
 libs/string/stringfwd.h include/ientity.h libs/signal/signal.h \
 libs/signal/isignal.h libs/gtkutil/image.h \
 C:/msys64/mingw64/include/QtGui/QPixmap \
 C:/msys64/mingw64/include/QtGui/qpixmap.h radiant/gtkmisc.h \
 C:/msys64/mingw64/include/QtWidgets/QToolBar \
 C:/msys64/mingw64/include/QtWidgets/qtoolbar.h radiant/windowobservers.h \
 include/windowobserver.h libs/generic/bitfield.h \
 libs/generic/enumeration.h C:/msys64/mingw64/include/QtCore/Qt \
 C:/msys64/mingw64/include/QtCore/qnamespace.h radiant/commands.h \
 libs/gtkutil/accelerator.h C:/msys64/mingw64/include/QtGui/QKeySequence \
 C:/msys64/mingw64/include/QtGui/qkeysequence.h
