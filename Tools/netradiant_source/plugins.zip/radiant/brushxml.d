radiant/brushxml.o: radiant/brushxml.cpp radiant/brushxml.h \
 libs/stream/stringstream.h include/itextstream.h libs/generic/static.h \
 libs/string/string.h libs/memory/allocator.h libs/generic/object.h \
 libs/generic/arrayrange.h libs/xml/xmlelement.h libs/xml/ixml.h \
 libs/generic/constant.h radiant/brush.h libs/debugging/debugging.h \
 libs/stream/textstream.h include/itexdef.h include/iundo.h \
 libs/generic/callback.h libs/generic/functional.h include/modulesystem.h \
 include/iselection.h libs/signal/signalfwd.h libs/math/vectorfwd.h \
 include/irender.h libs/generic/vector.h include/imap.h \
 include/iscenegraph.h include/ibrush.h include/igl.h \
 C:/msys64/mingw64/include/QtGui/QOpenGLFunctions_2_0 \
 C:/msys64/mingw64/include/QtGui/qopenglfunctions_2_0.h \
 libs/gtkutil/glfont.h include/ifilter.h include/nameable.h \
 include/moduleobserver.h include/cullable.h include/renderable.h \
 include/selectable.h libs/scenelib.h libs/math/aabb.h libs/math/matrix.h \
 libs/math/vector.h libs/math/pi.h libs/math/plane.h libs/transformlib.h \
 libs/math/quaternion.h libs/generic/reference.h libs/container/stack.h \
 libs/typesystem.h libs/generic/referencecounted.h include/editable.h \
 include/mapfile.h libs/math/frustum.h libs/generic/enumeration.h \
 libs/math/line.h libs/selectionlib.h libs/render.h \
 libs/container/array.h libs/texturelib.h libs/container/container.h \
 libs/generic/bitfield.h radiant/winding.h radiant/brush_primit.h \
 libs/shaderlib.h libs/character.h include/ishaders.h
