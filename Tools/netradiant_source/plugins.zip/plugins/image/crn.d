plugins/image/crn.o: plugins/image/crn.cpp plugins/image/crn.h \
 include/iarchive.h libs/generic/constant.h libs/stream/textstream.h \
 include/itextstream.h libs/generic/static.h libs/generic/arrayrange.h \
 libs/crnlib/crnlib.h libs/imagelib.h include/iimage.h \
 include/idatastream.h
