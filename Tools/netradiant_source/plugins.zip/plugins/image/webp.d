plugins/image/webp.o: plugins/image/webp.cpp plugins/image/webp.h \
 include/iarchive.h libs/generic/constant.h libs/stream/textstream.h \
 include/itextstream.h libs/generic/static.h libs/generic/arrayrange.h \
 libs/webplib/webplib.h libs/imagelib.h include/iimage.h \
 include/idatastream.h
