plugins/assmodel/glbarchive.o: plugins/assmodel/glbarchive.cpp \
 plugins/assmodel/glbarchive.h include/iarchive.h libs/generic/constant.h \
 include/idatastream.h include/ifilesystem.h libs/generic/callback.h \
 libs/generic/functional.h include/modulesystem.h libs/generic/static.h \
 libs/debugging/debugging.h libs/stream/textstream.h \
 include/itextstream.h libs/generic/arrayrange.h libs/string/string.h \
 libs/memory/allocator.h libs/generic/object.h
