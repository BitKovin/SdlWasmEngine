plugins/entity/customgizmos.o: plugins/entity/customgizmos.cpp \
 plugins/entity/customgizmos.h include/renderable.h \
 libs/generic/constant.h libs/render.h include/irender.h \
 libs/generic/callback.h libs/generic/functional.h libs/generic/vector.h \
 include/modulesystem.h libs/generic/static.h libs/debugging/debugging.h \
 libs/stream/textstream.h include/itextstream.h libs/generic/arrayrange.h \
 include/igl.h C:/msys64/mingw64/include/QtGui/QOpenGLFunctions_2_0 \
 C:/msys64/mingw64/include/QtGui/qopenglfunctions_2_0.h \
 libs/gtkutil/glfont.h libs/container/array.h libs/memory/allocator.h \
 libs/generic/object.h libs/math/vector.h libs/math/pi.h libs/math/aabb.h \
 libs/math/matrix.h libs/math/plane.h libs/stringio.h include/iscriplib.h \
 libs/string/string.h plugins/entity/entity.h plugins/entity/targetable.h \
 include/cullable.h libs/math/vectorfwd.h libs/math/line.h \
 libs/selectionlib.h include/iselection.h libs/signal/signalfwd.h \
 libs/scenelib.h include/iscenegraph.h libs/transformlib.h \
 libs/math/quaternion.h libs/generic/reference.h libs/container/stack.h \
 libs/typesystem.h libs/generic/referencecounted.h libs/entitylib.h \
 include/ireference.h include/ientity.h include/selectable.h \
 libs/undolib.h include/iundo.h include/mapfile.h \
 libs/string/pooledstring.h libs/container/hashtable.h \
 libs/container/hashfunc.h libs/container/container.h libs/eclasslib.h \
 include/ieclass.h
